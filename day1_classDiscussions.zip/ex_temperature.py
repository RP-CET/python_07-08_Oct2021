name = input("Enter patient's name: ")
temperature = float(input("Enter patient's temperature: "))
difference = round(temperature - 36.9, 2)
print(name +"'s temperature is "+str(difference) + " celsius from 36.9 degree")

