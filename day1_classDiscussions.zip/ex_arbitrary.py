def addAll(*args):
    total = 0
    for num in args:
        total += num
    return total

print(addAll(1,2,4))
print(addAll(1,2,4,5,7,99))


'''
def introduce(name="Nobody", school="RP"):
    print("I am "+name +" from "+school)
    
introduce(school="Republic")
'''