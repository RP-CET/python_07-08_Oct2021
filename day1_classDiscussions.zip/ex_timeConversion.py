minutes = 1000//60
seconds = 1000 % 60

print("Minutes: "+ str(minutes))
print("Remaining Seconds: "+str(seconds))
print("Time in mins and sec : "+str(minutes)+" min and "+str(seconds)+" sec")
print("Time in mins and sec : %d min and %d sec" % (minutes, seconds))

'''

favfavfayfv
'''