
#Contains codes that are done during class, for sharing

#-----------------
name = input("Enter patient's name: ")
temperature = float(input("Enter patient's temperature: "))
difference = round(temperature - 36.9, 2)
print(name +"'s temperature is "+str(difference) + " celsius from 36.9 degree")

#--------------------------
sports = input("Enter fav sports: ")
print(sports)
sports = sports.lower()
print(sports)
if sports == "soccer":
    print("Your fav sports is soccer")
elif sports == "basketball":
    print("Your fav sports is basketball")
elif sports == "badminton":
    print("Your fav sports is badminton")
else:
    print("Invalid sports")
#--------------------------
weight = input("Enter your weight: ")
weight = float(weight)

height = input("Enter your height: ")
height = float(height)

bmi = weight/(height * height)
print ("BMI is: "+str(bmi))
if bmi <18:
    print("Underweight")
elif bmi <25:  #>=18  (elif bmi>=18 and bmi <25)
    print("Ideal")
elif bmi <30:
    print("Overweight")
else:
    print("Obese")
#--------------------------
num_even = 0  #keep track how many even numbers
num_odd = 0 #keep track how may odd numbers
for i in range(1,11):
    # Get user input
    number = int(input("Enter number "+str(i)+":"))
    
    #check if odd or even: if x%2 == 0 => even
    if number%2 == 0:
        num_even = num_even + 1
    else:
        num_odd = num_odd + 1

print("Even # :"+str(num_even))
print("Odd # :"+str(num_odd))
#--------------------------

def sayHello(name):
    print("Hello "+name)
    
sayHello("John") #go to Line 1, John->name, print John
sayHello("Batman")#go 

#--------------------------

def getBiggerNumber(num1, num2):
    if num1 > num2:
        return num1
    else:
        return num2 to Line 1, Batman->name, print Batman
      
#--------------------------

#returns the number
def func1(num):
    return num

ans = func1(6)
print(ans)

#returns the number when increment by 1
def func2(num):
    return num+1
ans = func2(6)
print(ans)

#returns double the number
def func3(num):
    return num*2
ans = func3(6)
print(ans)

#------------------- 
def get_discount(ori_price, discount):
    return ori_price - (discount/100)*ori_price

ans = get_discount(100,10)
print(ans)

ans = get_discount(120,30)
print(ans)
        
#-------------------  
def get_sum(mylist):
    total = 0
    for i in mylist:
        total = total + i
    return (total)

mylist = [2,3,5,9,4,6]
ans = get_sum(mylist)
print(ans)

#------------------
mylist = [2,3,5,9,4,6, 9,6,5,-1]
print(sum(mylist))
print(max(mylist))
print(min(mylist))

#------------------
from urllib.request import urlopen
def isOnline(reliableserver):
    try:
        urlopen(reliableserver)
        return True
    except IOError:
        return False
print(isOnline('http://www.google.com'))

#-------------------
import time
from urllib.request import urlopen
def isOnline(reliableserver):
    try:
        urlopen(reliableserver)
        named_tuple = time.localtime() # get struct_time
        time_string = time.strftime("%b %d/%Y, %H:%M:%S", named_tuple)        
        
        print(str(time_string) + " : "+ reliableserver+" is alive")
    except IOError:
        print(reliableserver+" - something went wrong")

while True:
    isOnline('http://www.google.com')
    time.sleep(5)
    
#-----------------
data = "Tay Mei Lan,20,RP"  #string
dataList = data.split(",")
print(dataList)
print("Name: "+dataList[0])

#-------------------
data = "Tay Mei Lan,20,RP"  #string
dataList = data.split(",")
print(dataList)

name = dataList[0].upper()
nameList = name.split(" ")
print("Last name: "+nameList[0])
print("Name: "+name)

print("School: "+dataList[2])

#----------------
def findLongestWord(sentence):
    longest = ""
    #Step 1: split the sentence
    
    #Step 2: use length of word to compare
    
    return longest

#calling function
sentence = "I am very happy"
print(len(sentence))
longestWord = findLongestWord(sentence)
print(longestWord)

#---------completed---
def findLongestWord(sentence):
    longest = ""
    #Step 1: split the sentence
    wordList = sentence.split()
    print(wordList)
    
    #Step 2: use length of word to compare
    for eachWord in wordList:
        if len(eachWord) > len(longest):
            longest = eachWord
    
    return longest

#calling function
sentence = "I am very happy now"
print(len(sentence))
longestWord = findLongestWord(sentence)
print(longestWord)

#----------------
print("Number of items is %-8d. Please pay %.2f"%(5, 5.666))

#---------------
for i in range(1,20):
    half = i* "#"
    print("%20s%-20s"%(half, half))
    
    
#-----------------
import random
namelist = ["peter", "mary", "john", "alice"]
a = random.choice(namelist)
print(a)

'''
for i in range(10):
    a = random.randint(1, 9999)
    print("Lucky number: %04d"%(a))
'''

#----------- Receipt.py sample ----
items = ["Watermelon", "Apples", "Mangos", "Pizza"]
prices = [5.00, 14.00, 140.33, 20.50]

for i in range( len(items)):
    line = "%-25s $ %.2f" % (items[i], prices[i])
    print (line)

print ("-" * 35)
print ("%-25s $ %.2f" % ("Total : ", sum(prices)) )

#----------------
import random
secret = random.randint(1,20)
print(secret)

name = input("Enter your name: ")
print("Well, "+name+". I am thinking of a number between 1-20")

for i in range(1,7):
    guess = int(input("Take a guess: "))
    if guess > secret:
        print("Your guess is too high")
    elif guess < secret:
        print("Your guess is too low")
    else:
        print("Good job! You got it in "+str(i)+" tries")
        break

           