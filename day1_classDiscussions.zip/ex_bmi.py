weight = input("Enter your weight: ")
weight = float(weight)

height = input("Enter your height: ")
height = float(height)

bmi = weight/(height * height)
print ("BMI is: "+str(bmi))
if bmi <18:
    print("Underweight")
elif bmi <25:  #>=18  (elif bmi>=18 and bmi <25)
    print("Ideal")
elif bmi <30:
    print("Overweight")
else:
    print("Obese")
    

