for i in range(2, 10, 3):
    print(i, end=",")