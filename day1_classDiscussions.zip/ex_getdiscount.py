def get_discount(ori_price, discount):
    return ori_price - (discount/100)*ori_price

ans = get_discount(100,10)
print(ans)

ans = get_discount(120,30)
print(ans)



'''
price = $120, 15%

120 - (15/100)*120

120 => ori_price
15 => discount
'''