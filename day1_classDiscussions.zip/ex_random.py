import random
namelist = ["peter", "mary", "john", "alice"]
a = random.choice(namelist)
print(a)

'''
for i in range(10):
    a = random.randint(1, 9999)
    print("Lucky number: %04d"%(a))
'''