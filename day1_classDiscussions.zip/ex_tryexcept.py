import time
from urllib.request import urlopen
def isOnline(reliableserver):
    try:
        urlopen(reliableserver)
        named_tuple = time.localtime() # get struct_time
        time_string = time.strftime("%b %d/%Y, %H:%M:%S", named_tuple)        
        
        print(str(time_string) + " : "+ reliableserver+" is alive")
    except IOError:
        print(reliableserver+" - something went wrong")

while True:
    isOnline('http://www.google.com')
    time.sleep(5)
        
        

'''
try:
    print(5/1)
except:
    print("Error")
finally:
    print("Good bye")
'''