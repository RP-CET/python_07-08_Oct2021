mylist = [2,3,5,9,4,6, 9,6,5,-1]
print(sum(mylist))
print(max(mylist))
print(min(mylist))
'''
def get_sum(mylist):
    total = 0
    for i in mylist:
        total = total + i
    return (total)

mylist = [2,3,5,9,4,6]
ans = get_sum(mylist)
print(ans)
'''