def findLongestWord(sentence):
    longest = ""
    #Step 1: split the sentence
    wordList = sentence.split()
    print(wordList)
    
    #Step 2: use length of word to compare
    for eachWord in wordList:
        if len(eachWord) > len(longest):
            longest = eachWord
    
    return longest

#calling function
sentence = "I am very happy now"
print(len(sentence))
longestWord = findLongestWord(sentence)
print(longestWord)