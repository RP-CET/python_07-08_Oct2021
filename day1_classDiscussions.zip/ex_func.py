#returns the number
def func1(num):
    return num

ans = func1(6)
print(ans)

#returns the number when increment by 1
def func2(num):
    return num+1
ans = func2(6)
print(ans)

#returns double the number
def func3(num):
    return num*2
ans = func3(6)
print(ans)
'''
def getBiggerNumber(num1, num2):
    if num1 > num2:
        return num1
    else:
        return num2

#Calling the function
answer = getBiggerNumber(4, 8)
print(answer)
'''
'''
def area_circle(radius):
    return 3.14 * radius * radius

areaA = area_circle(5)
areaB = area_circle(3)
print("Diff: "+str(areaA-areaB))
'''

'''
def sayHello(name):
    print("Hello "+name)
    
sayHello("John") #go to Line 1, John->name, print John
sayHello("Batman")#go to Line 1, Batman->name, print Batman
'''