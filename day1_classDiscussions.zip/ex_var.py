age = 15
print("My age is :       "+ str(age))

'''
a = 51.0
b = 6.5
print(a+b)
print(type(a+b))
'''