num_even = 0  #keep track how many even numbers
num_odd = 0 #keep track how may odd numbers
for i in range(1,11):
    # Get user input
    number = int(input("Enter number "+str(i)+":"))
    
    #check if odd or even: if x%2 == 0 => even
    if number%2 == 0:
        num_even = num_even + 1
    else:
        num_odd = num_odd + 1

print("Even # :"+str(num_even))
print("Odd # :"+str(num_odd))
        