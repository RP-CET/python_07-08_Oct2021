mick = 3.5
alice = 2.5
total_hr = mick + alice
print(total_hr)
total_sec = total_hr * 60 *60
print("Number of seconds: "+str(total_sec))
