mylist = [1, 5, 15]
mylist.append(20)
print(mylist)

mylist.remove(5)
print(mylist)

'''
mylist = [3,9,6]
mylist.append(8)
print(mylist)

mylist.insert(0, "apple")
print(mylist)

#Remove by value (remove 3 from list)
mylist.remove(3)
print(mylist)

#Remove by position (-1 means last)
mylist.pop(-1)
print(mylist)
'''
'''
mylist.reverse()
print(mylist)
mylist.sort()
print(mylist)
'''