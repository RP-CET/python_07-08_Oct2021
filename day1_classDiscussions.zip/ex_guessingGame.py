import random
secret = random.randint(1,20)
print(secret)

name = input("Enter your name: ")
print("Well, "+name+". I am thinking of a number between 1-20")

for i in range(1,7):
    guess = int(input("Take a guess: "))
    if guess > secret:
        print("Your guess is too high")
    elif guess < secret:
        print("Your guess is too low")
    else:
        print("Good job! You got it in "+str(i)+" tries")
        break

           