data = "Tay Mei Lan,20,RP"  #string
dataList = data.split(",")
print(dataList)

name = dataList[0].upper()
nameList = name.split(" ")
print("Last name: "+nameList[0])
print("Name: "+name)

print("School: "+dataList[2])