sports = input("Enter fav sports: ")
print(sports)
sports = sports.lower()
print(sports)
if sports == "soccer":
    print("Your fav sports is soccer")
elif sports == "basketball":
    print("Your fav sports is basketball")
elif sports == "badminton":
    print("Your fav sports is badminton")
else:
    print("Invalid sports")
    
    