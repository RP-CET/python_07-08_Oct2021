num = 6
for i in range(1,num):
    half = i* "#"
    print("%20s%-20s"%(half, half))

'''
print("Number of items is %-8d. Please pay %.2f"%(5, 5.666))
'''